import React, { useState } from 'react'
import "./Hero.css"
import MapModal from '../map/MapModal'

function Hero() {
  const [showMap, setShowMap] = useState(false)

  const handleEmergency = () => {
    setShowMap(true)
  }

  return (
    <div className="hero">
      <h1 className='hero-heading'>For Emergency Click the below button</h1>
      <button className='btn' onClick={handleEmergency}>Emergency</button>
      {showMap && <MapModal onClose={() => setShowMap(false)} />}
    </div>
  )
}

export default Hero