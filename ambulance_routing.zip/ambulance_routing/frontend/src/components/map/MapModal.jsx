import React, { useEffect, useState } from 'react'
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet'
import './MapModal.css'
import L from 'leaflet';

// Custom icon for user location
const userIcon = new L.Icon({
  iconUrl: 'https://cdn-icons-png.flaticon.com/512/4872/4872109.png',
  iconSize: [40, 40],
  iconAnchor: [20, 40],
  popupAnchor: [0, -40],
  
});

// Custom icon for hospital
const hospitalIcon = new L.Icon({
  iconUrl: 'https://cdn-icons-png.flaticon.com/512/2972/2972377.png',
  
  iconSize: [40, 40],
  iconAnchor: [20, 40],
  popupAnchor: [0, -40],
  className : "hosp-icon",
});

// Utility to fix map size rendering
function MapRefresher() {
  const map = useMap()
  useEffect(() => {
    setTimeout(() => {
      map.invalidateSize()
    }, 100)
  }, [map])
  return null
}

function MapModal({ onClose }) {
  const [location, setLocation] = useState(null)
  const [hospitals, setHospitals] = useState([])

  // 
  useEffect(() => {
    navigator.geolocation.getCurrentPosition(async (position) => {
      const { latitude, longitude } = position.coords;
      setLocation({ lat: latitude, lng: longitude });
  
      // Fetching the optimal hospital from the API
      try {
        const response = await fetch(
          `http://localhost:8000/api/hospital/optimal-hospital/?lat=${latitude}&lng=${longitude}`
        );
        const data = await response.json();
        
        // Assuming data is an object with a 'hospital' property
        const hospital = data.hospital;
  
        if (hospital) {
          // Update hospitals state with a single hospital (not an array)
          setHospitals([
            {
              id: hospital.id,
              name: hospital.name,
              lat: hospital.location.lat,
              lng: hospital.location.lng,
            }
          ]);
        } else {
          console.error("No hospital found in response");
        }
      } catch (error) {
        console.error("Error fetching hospitals:", error);
      }
    });
  }, []);


  return (
    <div className="modal">
      <button className="close-btn" onClick={onClose}>Close</button>
      {location ? (
        <div className="map-container">
          <MapContainer
            center={location}
            zoom={13}
            scrollWheelZoom={true}
            style={{ height: "100%", width: "100%" }}
          >
            <MapRefresher />
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <Marker position={location}>
              <Popup>You are here</Popup>
            </Marker>
            {hospitals.map((hospital, index) => (
              <Marker key={index} position={{ lat: hospital.lat, lng: hospital.lng }}>
                <Popup>{hospital.name}</Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>
      ) : (
        <p style={{ color: 'white' }}>Loading map...</p>
      )}
    </div>
  )
}

export default MapModal