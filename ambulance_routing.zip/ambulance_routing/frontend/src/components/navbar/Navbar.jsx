import React from 'react'
import "./Navbar.css"
import {Link} from 'react-router-dom';
function Navbar() {
  return (
    <nav>
        <h1 className='heading'>Health Care</h1>
        <ul className='navbar-ul'>
            <li className='log'><Link to='/login'>Login</Link></li>
            <li>About</li>
            <li>Help</li>
        </ul>
    </nav>
  )
}

export default Navbar