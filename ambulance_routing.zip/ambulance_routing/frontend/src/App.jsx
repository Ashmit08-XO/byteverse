import React from 'react'
import "./App.css"
import Navbar from './components/navbar/Navbar'
import Hero from './components/hero/Hero'
// import Footer from './components/Footer/Footer'
import Footer from './components/footer/Footer'
import { BrowserRouter as  Router,Routes,Route } from 'react-router-dom'
import Login from './pages/login/Login'

function App() {
  return (
    <>
    
   
    <Router>
    <Navbar/>
      <Routes>
        <Route path="/login" element={<Login/>}/>
      </Routes>
    </Router>
    
    <div className="app-cards">
    <Hero/>
  
    </div>

    <Footer/>
   
    </>
  )
}

export default App