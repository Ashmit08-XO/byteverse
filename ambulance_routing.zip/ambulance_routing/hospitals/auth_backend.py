from django.contrib.auth.backends import ModelBackend
from .models import Hospital

class HospitalBackend(ModelBackend):
    def authenticate(self, request, name=None, password=None, **kwargs):
        try:
            hospital = Hospital.objects.get(name=name)
            if hospital.check_password(password):
                return hospital
        except Hospital.DoesNotExist:
            return None
