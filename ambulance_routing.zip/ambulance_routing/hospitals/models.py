from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin

class HospitalManager(BaseUserManager):
    def create_user(self, name, address, latitude, longitude, password=None):
        if not name:
            raise ValueError('Hospitals must have a name')
        if not address:
            raise ValueError('Hospitals must have an address')
        
        user = self.model(
            name=name,
            address=address,
            latitude=latitude,
            longitude=longitude,
        )
        
        user.set_password(password)
        user.save(using=self._db)
        return user
    
    def create_superuser(self, name, address, latitude, longitude, password):
        user = self.create_user(
            name=name,
            address=address,
            latitude=latitude,
            longitude=longitude,
            password=password,
        )
        user.is_admin = True
        user.is_staff = True
        user.is_superuser = True
        user.save(using=self._db)
        return user

class Hospital(AbstractBaseUser, PermissionsMixin):
    name = models.CharField(max_length=255, unique=True)
    address = models.TextField()
    latitude = models.DecimalField(max_digits=9, decimal_places=6)
    longitude = models.DecimalField(max_digits=9, decimal_places=6)
    
    # Required fields
    date_joined = models.DateTimeField(auto_now_add=True)
    last_login = models.DateTimeField(auto_now=True)
    is_admin = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    
    # Add these to resolve the conflicts
    groups = models.ManyToManyField(
        'auth.Group',
        verbose_name='groups',
        blank=True,
        help_text='The groups this user belongs to. A user will get all permissions granted to each of their groups.',
        related_name="hospital_groups",  # Changed from default
        related_query_name="hospital",
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        verbose_name='user permissions',
        blank=True,
        help_text='Specific permissions for this user.',
        related_name="hospital_user_permissions",  # Changed from default
        related_query_name="hospital",
    )
    
    objects = HospitalManager()
    
    USERNAME_FIELD = 'name'
    REQUIRED_FIELDS = ['address', 'latitude', 'longitude']
    
    def __str__(self):
        return self.name
    
    def has_perm(self, perm, obj=None):
        return self.is_admin
    
    def has_module_perms(self, app_label):
        return True