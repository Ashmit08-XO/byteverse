from rest_framework import serializers
from django.contrib.auth import authenticate
from .models import Hospital
from rest_framework_simplejwt.tokens import RefreshToken

class HospitalRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    
    class Meta:
        model = Hospital
        fields = ['name', 'address', 'latitude', 'longitude', 'password']
    
    def create(self, validated_data):
        return Hospital.objects.create_user(**validated_data)

class HospitalLoginSerializer(serializers.Serializer):
    name = serializers.CharField()
    password = serializers.CharField(write_only=True)
    
    def validate(self, data):
        name = data.get('name')
        password = data.get('password')
        
        if name and password:
            hospital = authenticate(name=name, password=password)

            if hospital:
                if not hospital.is_active:
                    raise serializers.ValidationError('Hospital account is disabled.')
                return hospital
            raise serializers.ValidationError('Unable to log in with provided credentials.')
        raise serializers.ValidationError('Must include "name" and "password".')

class HospitalProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Hospital
        fields = ['name', 'address', 'latitude', 'longitude']