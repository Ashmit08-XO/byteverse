from django.urls import path
from .views import (
    HospitalRegistrationView,
    HospitalLoginView,
    HospitalProfileView, 
    HospitalListView,
)
from hospitals.routing.views import OptimalHospitalView

urlpatterns = [
    path('register/', HospitalRegistrationView.as_view(), name='hospital-register'),
    path('login/', HospitalLoginView.as_view(), name='hospital-login'),
    path('profile/', HospitalProfileView.as_view(), name='hospital-profile'),
    path('optimal-hospital/', OptimalHospitalView.as_view(), name='optimal_hospital'),
    path('hospitals/', HospitalListView.as_view(), name='hospital-list'),
]